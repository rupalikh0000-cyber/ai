export type AppCommandType =
  | 'OPEN_APP'
  | 'CLOSE_APP'
  | 'CALL'
  | 'SMS'
  | 'WHATSAPP_MSG'
  | 'WHATSAPP_CALL'
  | 'PRIME_CALL'
  | 'PRIME_MSG'
  | 'VOLUME_UP'
  | 'VOLUME_DOWN'
  | 'FLASHLIGHT_ON'
  | 'FLASHLIGHT_OFF'
  | 'WIFI_ON'
  | 'WIFI_OFF'
  | 'BLUETOOTH_ON'
  | 'BLUETOOTH_OFF';

export interface AppCommand {
  type: AppCommandType;
  params: Record<string, string>;
}

export interface ChatMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: number;
}

export interface PrimeContact {
  name: string;
  number: string;
}

export type PersonalityMode = 'gf' | 'professional' | 'assistant';

export interface Settings {
  apiKey: string;
  userName: string;
  model: string;
  voice: string;
  personality: PersonalityMode;
  primeContacts: PrimeContact[];
}

export type OrbState = 'idle' | 'listening' | 'speaking' | 'thinking' | 'active';
