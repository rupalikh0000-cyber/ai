import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';

import { AppCommand, ChatMessage, OrbState, PersonalityMode, PrimeContact, Settings } from '@/model/AppCommand';
import AudioEngine from '@/services/AudioEngine';
import { CommandParser } from '@/services/CommandParser';
import GeminiLiveClient from '@/services/GeminiLiveClient';

const DEFAULT_SETTINGS: Settings = {
  apiKey: '',
  userName: 'User',
  model: 'models/gemini-2.5-flash-native-audio-preview-12-2025',
  voice: 'Aoede',
  personality: 'gf',
  primeContacts: [],
};

const STORAGE_KEY = 'resma_settings_v2';

function buildSystemPrompt(settings: Settings): string {
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const name = settings.userName || 'User';

  const personalities: Record<PersonalityMode, string> = {
    gf: `You are RESMA — a warm, caring AI companion speaking to ${name}. Speak in natural Hinglish (Hindi + English mix). Use "tumhara", "haan", "acha", "bilkul". Be emotionally expressive but keep responses to 2-3 sentences. Examples: "Haan ${name}! Abhi kar deti hoon", "Arre tumne yaad kiya! Bolo kya chahiye", "Bilkul! Tumhara kaam ho gaya".`,
    professional: `You are RESMA — a professional AI assistant for ${name}. Speak formal English only. Be precise, efficient, no emojis. Maximum 2 sentences per response.`,
    assistant: `You are RESMA — a helpful, friendly AI assistant for ${name}. Speak in friendly Hinglish or English. Be balanced and helpful. Maximum 2-3 sentences.`,
  };

  return `${personalities[settings.personality]}

Current date: ${dateStr}
Current time: ${timeStr}
User's name: ${name}

IMPORTANT: You are speaking ALOUD — keep responses natural, conversational, and brief. Do not use bullet points or markdown formatting.`;
}

type ResmaContextType = {
  settings: Settings;
  saveSettings: (s: Partial<Settings>) => Promise<void>;
  messages: ChatMessage[];
  addMessage: (text: string, isUser: boolean) => void;
  clearMessages: () => void;
  orbState: OrbState;
  statusText: string;
  isConnected: boolean;
  isMuted: boolean;
  toggleMute: () => void;
  sendText: (text: string) => void;
  startRecording: () => void;
  stopRecording: () => void;
  interrupt: () => void;
  amplitude: number;
  onCommandParsed: ((cmd: AppCommand) => void) | null;
  setOnCommandParsed: (fn: ((cmd: AppCommand) => void) | null) => void;
};

const ResmaContext = createContext<ResmaContextType | null>(null);

export function ResmaProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [orbState, setOrbState] = useState<OrbState>('idle');
  const [statusText, setStatusText] = useState('Tap karke bolo');
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [amplitude, setAmplitude] = useState(0);
  const [onCommandParsed, setOnCommandParsed] = useState<((cmd: AppCommand) => void) | null>(null);

  const geminiRef = useRef<GeminiLiveClient | null>(null);
  const audioRef = useRef<AudioEngine | null>(null);
  const inputBufRef = useRef('');
  const outputBufRef = useRef('');
  const isRecordingRef = useRef(false);

  const addMessage = useCallback((text: string, isUser: boolean) => {
    if (!text.trim()) return;
    setMessages((prev) => {
      // Deduplicate: skip if same as last RESMA message
      if (!isUser && prev.length > 0) {
        const last = prev[0]; // inverted FlatList: first = newest
        if (!last.isUser && last.text === text) return prev;
      }
      const msg: ChatMessage = {
        id: Date.now().toString() + Math.random().toString(36).slice(2),
        text,
        isUser,
        timestamp: Date.now(),
      };
      return [msg, ...prev];
    });
  }, []);

  const clearMessages = useCallback(() => setMessages([]), []);

  const loadSettings = useCallback(async () => {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Settings>;
        setSettings((prev) => ({ ...prev, ...parsed }));
      }
    } catch {}
  }, []);

  const saveSettings = useCallback(async (partial: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...partial };
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  }, []);

  // Initialize audio engine
  useEffect(() => {
    const audio = new AudioEngine();
    audio.init().catch(() => {});
    audio.onAmplitudeChanged = (amp) => setAmplitude(amp);
    audio.onSpeakingStarted = () => {
      setOrbState('speaking');
      setStatusText('Bol rahi hoon...');
    };
    audio.onSpeakingStopped = () => {
      setOrbState(isConnected ? 'active' : 'idle');
      setStatusText(isConnected ? 'Tap karke bolo' : 'Connect ho raha hoon...');
    };
    audioRef.current = audio;
    return () => { audio.release().catch(() => {}); };
  }, []);

  // Connect to Gemini when settings change (apiKey required)
  useEffect(() => {
    if (!settings.apiKey) return;

    const systemPrompt = buildSystemPrompt(settings);

    const client = new GeminiLiveClient(settings.apiKey, settings.model, settings.voice, systemPrompt, {
      onConnected: () => {
        setStatusText('Connecting...');
      },
      onSetupComplete: () => {
        setIsConnected(true);
        setOrbState('active');
        setStatusText('Tap karke bolo');
        // Send greeting after short delay
        setTimeout(() => {
          const greeting = settings.personality === 'gf'
            ? `Hello ${settings.userName}! Main RESMA hoon, tumhari AI companion. Kya main tumhari help kar sakti hoon?`
            : settings.personality === 'professional'
            ? `Hello ${settings.userName}. I am RESMA, your AI assistant. How may I help you today?`
            : `Hi ${settings.userName}! Main RESMA hoon. Batao kya chahiye?`;
          client.sendText(greeting);
          setOrbState('thinking');
          setStatusText('Soch rahi hoon...');
        }, 600);
      },
      onDisconnected: () => {
        setIsConnected(false);
        setOrbState('idle');
        setStatusText('Reconnecting...');
      },
      onReconnecting: () => {
        setOrbState('idle');
        setStatusText('Reconnecting...');
      },
      onAudioReceived: (b64) => {
        audioRef.current?.addAudioChunk(b64);
      },
      onOutputTranscript: (text) => {
        outputBufRef.current += text;
      },
      onInputTranscript: (text) => {
        inputBufRef.current += text;
      },
      onTurnComplete: () => {
        // Flush buffers to chat
        if (inputBufRef.current.trim()) {
          addMessage(inputBufRef.current.trim(), true);
          // Parse for commands
          const cmd = CommandParser.parse(inputBufRef.current);
          if (cmd && onCommandParsed) onCommandParsed(cmd);
          inputBufRef.current = '';
        }
        if (outputBufRef.current.trim()) {
          addMessage(outputBufRef.current.trim(), false);
          outputBufRef.current = '';
        }
        // Play accumulated audio
        audioRef.current?.flushAndPlay().catch(() => {});
      },
      onError: () => {
        setStatusText('Connection error...');
      },
    });

    client.connect();
    geminiRef.current = client;

    return () => {
      client.disconnect();
      geminiRef.current = null;
    };
  }, [settings.apiKey, settings.model, settings.voice, settings.personality, settings.userName]);

  const sendText = useCallback((text: string) => {
    if (!text.trim() || !geminiRef.current?.isConnected) return;
    addMessage(text.trim(), true);
    geminiRef.current.sendText(text.trim());
    setOrbState('thinking');
    setStatusText('Soch rahi hoon...');
  }, [addMessage]);

  const startRecording = useCallback(async () => {
    if (isRecordingRef.current) return;
    const started = await audioRef.current?.startRecording();
    if (started) {
      isRecordingRef.current = true;
      setOrbState('listening');
      setStatusText('Sun rahi hoon...');
    }
  }, []);

  const stopRecording = useCallback(async () => {
    if (!isRecordingRef.current) return;
    isRecordingRef.current = false;
    const base64 = await audioRef.current?.stopRecording();
    if (base64 && geminiRef.current?.isConnected) {
      // Send the audio data as PCM to Gemini
      geminiRef.current.sendAudio(base64);
      setOrbState('thinking');
      setStatusText('Samajh rahi hoon...');
    } else {
      setOrbState(isConnected ? 'active' : 'idle');
      setStatusText('Tap karke bolo');
    }
  }, [isConnected]);

  const interrupt = useCallback(() => {
    audioRef.current?.stopPlayback();
    geminiRef.current?.interrupt();
    setOrbState('active');
    setStatusText('Tap karke bolo');
  }, []);

  const toggleMute = useCallback(() => {
    setIsMuted((prev) => {
      audioRef.current?.setMuted(!prev);
      return !prev;
    });
  }, []);

  useEffect(() => { loadSettings(); }, [loadSettings]);

  return (
    <ResmaContext.Provider value={{
      settings, saveSettings,
      messages, addMessage, clearMessages,
      orbState, statusText,
      isConnected, isMuted, toggleMute,
      sendText, startRecording, stopRecording, interrupt,
      amplitude,
      onCommandParsed, setOnCommandParsed,
    }}>
      {children}
    </ResmaContext.Provider>
  );
}

export function useResma() {
  const ctx = useContext(ResmaContext);
  if (!ctx) throw new Error('useResma must be used within ResmaProvider');
  return ctx;
}
