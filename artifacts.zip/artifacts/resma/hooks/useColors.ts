import colors from "@/constants/colors";

// RESMA always uses dark theme
export function useColors() {
  return { ...colors.dark, radius: colors.radius };
}
