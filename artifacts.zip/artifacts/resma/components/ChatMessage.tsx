import { BlurView } from 'expo-blur';
import React from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';

import { ChatMessage as ChatMessageType } from '@/model/AppCommand';

interface Props {
  message: ChatMessageType;
}

export default function ChatMessage({ message }: Props) {
  const isUser = message.isUser;

  if (Platform.OS === 'ios' || Platform.OS === 'android') {
    return (
      <View style={[styles.row, isUser ? styles.rowUser : styles.rowResma]}>
        {!isUser && <View style={styles.avatar} />}
        <BlurView
          intensity={isUser ? 12 : 8}
          tint="dark"
          style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleResma]}
        >
          <View style={[styles.bubbleInner, isUser ? styles.bubbleInnerUser : styles.bubbleInnerResma]}>
            <Text style={[styles.text, isUser ? styles.textUser : styles.textResma]}>
              {message.text}
            </Text>
          </View>
        </BlurView>
      </View>
    );
  }

  // Web fallback
  return (
    <View style={[styles.row, isUser ? styles.rowUser : styles.rowResma]}>
      {!isUser && <View style={styles.avatar} />}
      <View style={[styles.bubble, styles.bubbleWeb, isUser ? styles.bubbleUserWeb : styles.bubbleResmaWeb]}>
        <Text style={[styles.text, isUser ? styles.textUser : styles.textResma]}>
          {message.text}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginVertical: 4,
    paddingHorizontal: 12,
  },
  rowUser: {
    justifyContent: 'flex-end',
  },
  rowResma: {
    justifyContent: 'flex-start',
  },
  avatar: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FF1744',
    marginRight: 8,
    marginBottom: 6,
  },
  bubble: {
    maxWidth: '78%',
    borderRadius: 16,
    overflow: 'hidden',
  },
  bubbleInner: {
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 16,
    borderWidth: 1,
  },
  bubbleInnerUser: {
    backgroundColor: 'rgba(255,23,68,0.12)',
    borderColor: 'rgba(255,23,68,0.35)',
  },
  bubbleInnerResma: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderColor: 'rgba(255,255,255,0.12)',
  },
  bubbleUser: {},
  bubbleResma: {},
  // Web fallbacks
  bubbleWeb: {
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 16,
    borderWidth: 1,
  },
  bubbleUserWeb: {
    backgroundColor: 'rgba(255,23,68,0.15)',
    borderColor: 'rgba(255,23,68,0.4)',
  },
  bubbleResmaWeb: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderColor: 'rgba(255,255,255,0.15)',
  },
  text: {
    fontSize: 13,
    lineHeight: 19,
    fontFamily: 'Inter_400Regular',
  },
  textUser: {
    color: '#EEEEEE',
    textAlign: 'right',
  },
  textResma: {
    color: '#CCCCCC',
    textAlign: 'left',
  },
});
