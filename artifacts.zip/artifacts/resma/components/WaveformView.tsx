import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, View } from 'react-native';

interface Props {
  amplitude: number;
  isActive: boolean;
  color?: string;
  barCount?: number;
  height?: number;
  width?: number;
}

const BAR_COUNT = 20;

export default function WaveformView({
  amplitude,
  isActive,
  color = '#FF1744',
  barCount = BAR_COUNT,
  height = 40,
  width = 200,
}: Props) {
  const barAnims = useRef(Array.from({ length: barCount }, () => new Animated.Value(0.1))).current;
  const animRefs = useRef<Animated.CompositeAnimation[]>([]);

  useEffect(() => {
    if (!isActive) {
      // Animate bars to rest
      animRefs.current.forEach((a) => a.stop());
      animRefs.current = barAnims.map((anim) =>
        Animated.timing(anim, { toValue: 0.08, duration: 400, useNativeDriver: false })
      );
      animRefs.current.forEach((a) => a.start());
      return;
    }

    // Animate bars based on amplitude + randomness
    animRefs.current.forEach((a) => a.stop());
    animRefs.current = barAnims.map((anim, i) => {
      const centerBoost = 1 - Math.abs(i - barCount / 2) / (barCount / 2) * 0.4;
      const target = Math.max(0.08, Math.min(1, amplitude * centerBoost + Math.random() * 0.3));
      const duration = 100 + Math.random() * 150;
      return Animated.loop(
        Animated.sequence([
          Animated.timing(anim, { toValue: target, duration, easing: Easing.inOut(Easing.quad), useNativeDriver: false }),
          Animated.timing(anim, { toValue: Math.max(0.08, target * 0.4), duration, easing: Easing.inOut(Easing.quad), useNativeDriver: false }),
        ])
      );
    });
    animRefs.current.forEach((a) => a.start());

    return () => { animRefs.current.forEach((a) => a.stop()); };
  }, [isActive, amplitude]);

  const barWidth = (width - barCount * 2) / barCount;

  return (
    <View style={[styles.container, { width, height }]}>
      {barAnims.map((anim, i) => (
        <Animated.View
          key={i}
          style={[
            styles.bar,
            {
              width: Math.max(2, barWidth),
              height: anim.interpolate({ inputRange: [0, 1], outputRange: [2, height] }),
              backgroundColor: color,
              opacity: anim.interpolate({ inputRange: [0, 1], outputRange: [0.35, 1] }),
              borderRadius: 2,
            },
          ]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
  },
  bar: {
    borderRadius: 2,
  },
});
