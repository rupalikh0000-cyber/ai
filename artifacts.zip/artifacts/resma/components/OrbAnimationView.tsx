import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, View } from 'react-native';
import Svg, { Circle, Defs, RadialGradient, Stop } from 'react-native-svg';

import { OrbState } from '@/model/AppCommand';

interface OrbConfig {
  color1: string;
  color2: string;
  glowColor: string;
  ringColor: string;
}

const STATE_CONFIGS: Record<OrbState, OrbConfig> = {
  idle:      { color1: '#B71C1C', color2: '#880E4F', glowColor: '#B71C1C', ringColor: '#B71C1C' },
  active:    { color1: '#FF1744', color2: '#D500F9', glowColor: '#FF1744', ringColor: '#FF1744' },
  listening: { color1: '#FF1744', color2: '#D500F9', glowColor: '#FF1744', ringColor: '#FF1744' },
  speaking:  { color1: '#E040FB', color2: '#FF1744', glowColor: '#D500F9', ringColor: '#E040FB' },
  thinking:  { color1: '#40C4FF', color2: '#00B0FF', glowColor: '#00B0FF', ringColor: '#40C4FF' },
};

interface Props {
  state: OrbState;
  amplitude?: number;
  size?: number;
}

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

export default function OrbAnimationView({ state, amplitude = 0, size = 220 }: Props) {
  const config = STATE_CONFIGS[state];
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2;

  // Pulse animation (idle)
  const pulseAnim = useRef(new Animated.Value(1)).current;
  // Rotation for rings
  const ring1Rot = useRef(new Animated.Value(0)).current;
  const ring2Rot = useRef(new Animated.Value(0)).current;
  const ring3Rot = useRef(new Animated.Value(0)).current;
  // Wave scale
  const wave1 = useRef(new Animated.Value(1)).current;
  const wave2 = useRef(new Animated.Value(1)).current;
  // Thinking arc
  const thinkArc = useRef(new Animated.Value(0)).current;
  // Overall glow opacity
  const glowOpacity = useRef(new Animated.Value(0.5)).current;

  useEffect(() => {
    const animations: Animated.CompositeAnimation[] = [];

    // Pulse
    if (state === 'idle') {
      const pulse = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.1, duration: 1500, easing: Easing.inOut(Easing.sine), useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1.0, duration: 1500, easing: Easing.inOut(Easing.sine), useNativeDriver: true }),
        ])
      );
      animations.push(pulse);
      pulse.start();
    } else {
      Animated.timing(pulseAnim, { toValue: 1, duration: 200, useNativeDriver: true }).start();
    }

    // Rings rotation
    if (state !== 'idle') {
      const speed1 = state === 'speaking' ? 1200 : state === 'thinking' ? 800 : 2000;
      const speed2 = state === 'speaking' ? 1800 : state === 'thinking' ? 1200 : 3000;
      const speed3 = state === 'speaking' ? 2500 : state === 'thinking' ? 1600 : 4000;

      const r1 = Animated.loop(Animated.timing(ring1Rot, { toValue: 1, duration: speed1, easing: Easing.linear, useNativeDriver: true }));
      const r2 = Animated.loop(Animated.timing(ring2Rot, { toValue: -1, duration: speed2, easing: Easing.linear, useNativeDriver: true }));
      const r3 = Animated.loop(Animated.timing(ring3Rot, { toValue: 1, duration: speed3, easing: Easing.linear, useNativeDriver: true }));
      r1.start(); r2.start(); r3.start();
      animations.push(r1, r2, r3);
    } else {
      [ring1Rot, ring2Rot, ring3Rot].forEach((v) =>
        Animated.timing(v, { toValue: 0, duration: 500, useNativeDriver: true }).start()
      );
    }

    // Wave rings
    if (state === 'listening' || state === 'speaking' || state === 'active') {
      const waveSpeed = state === 'speaking' ? 600 : 900;
      const w1 = Animated.loop(
        Animated.sequence([
          Animated.timing(wave1, { toValue: 1.15, duration: waveSpeed, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(wave1, { toValue: 1.0, duration: waveSpeed, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        ])
      );
      const w2 = Animated.loop(
        Animated.sequence([
          Animated.timing(wave2, { toValue: 1.0, duration: waveSpeed, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(wave2, { toValue: 1.15, duration: waveSpeed, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        ])
      );
      w1.start(); w2.start();
      animations.push(w1, w2);
    }

    // Glow
    const targetGlow = state === 'idle' ? 0.35 : state === 'speaking' ? 0.9 : state === 'thinking' ? 0.7 : 0.6;
    const glow = Animated.loop(
      Animated.sequence([
        Animated.timing(glowOpacity, { toValue: targetGlow, duration: 1000, useNativeDriver: true }),
        Animated.timing(glowOpacity, { toValue: targetGlow * 0.6, duration: 1000, useNativeDriver: true }),
      ])
    );
    glow.start();
    animations.push(glow);

    return () => animations.forEach((a) => a.stop());
  }, [state]);

  const rot1 = ring1Rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const rot2 = ring2Rot.interpolate({ inputRange: [-1, 0], outputRange: ['-360deg', '0deg'] });
  const rot3 = ring3Rot.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  const extraScale = state === 'speaking' ? 1 + amplitude * 0.18 : 1;

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      {/* Wave rings — behind orb */}
      <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ scale: Animated.multiply(wave1, extraScale) }], opacity: glowOpacity }]}>
        <Svg width={size} height={size}>
          <Circle cx={cx} cy={cy} r={r * 0.95} fill="none" stroke={config.glowColor} strokeWidth={1} strokeOpacity={0.25} />
        </Svg>
      </Animated.View>
      <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ scale: wave2 }], opacity: Animated.multiply(glowOpacity, 0.6) }]}>
        <Svg width={size} height={size}>
          <Circle cx={cx} cy={cy} r={r * 0.90} fill="none" stroke={config.glowColor} strokeWidth={1} strokeOpacity={0.15} />
        </Svg>
      </Animated.View>

      {/* Outer glow */}
      <Animated.View style={[StyleSheet.absoluteFill, { opacity: glowOpacity, transform: [{ scale: pulseAnim }] }]}>
        <Svg width={size} height={size}>
          <Defs>
            <RadialGradient id="glow" cx="50%" cy="50%" r="50%">
              <Stop offset="0%" stopColor={config.glowColor} stopOpacity={0.4} />
              <Stop offset="60%" stopColor={config.glowColor} stopOpacity={0.1} />
              <Stop offset="100%" stopColor={config.glowColor} stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Circle cx={cx} cy={cy} r={r} fill="url(#glow)" />
        </Svg>
      </Animated.View>

      {/* Ring 1 */}
      {state !== 'idle' && (
        <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ rotate: rot1 }] }]}>
          <Svg width={size} height={size}>
            <Circle cx={cx} cy={cy} r={r * 0.82} fill="none" stroke={config.ringColor} strokeWidth={1.2} strokeOpacity={0.5} strokeDasharray="12 8" />
          </Svg>
        </Animated.View>
      )}

      {/* Ring 2 */}
      {state !== 'idle' && (
        <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ rotate: rot2 }] }]}>
          <Svg width={size} height={size}>
            <Circle cx={cx} cy={cy} r={r * 0.70} fill="none" stroke={config.ringColor} strokeWidth={0.8} strokeOpacity={0.4} strokeDasharray="6 10" />
          </Svg>
        </Animated.View>
      )}

      {/* Ring 3 */}
      {state !== 'idle' && (
        <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ rotate: rot3 }] }]}>
          <Svg width={size} height={size}>
            <Circle cx={cx} cy={cy} r={r * 0.93} fill="none" stroke={config.ringColor} strokeWidth={0.6} strokeOpacity={0.3} strokeDasharray="4 14" />
          </Svg>
        </Animated.View>
      )}

      {/* Core orb */}
      <Animated.View style={[StyleSheet.absoluteFill, { transform: [{ scale: Animated.multiply(pulseAnim, extraScale) }] }]}>
        <Svg width={size} height={size}>
          <Defs>
            <RadialGradient id="orb" cx="35%" cy="30%" r="70%">
              <Stop offset="0%" stopColor="#FFFFFF" stopOpacity={0.25} />
              <Stop offset="30%" stopColor={config.color1} stopOpacity={0.9} />
              <Stop offset="100%" stopColor={config.color2} stopOpacity={1} />
            </RadialGradient>
            <RadialGradient id="highlight" cx="30%" cy="25%" r="40%">
              <Stop offset="0%" stopColor="#FFFFFF" stopOpacity={0.35} />
              <Stop offset="100%" stopColor="#FFFFFF" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          {/* Glass orb body */}
          <Circle cx={cx} cy={cy} r={r * 0.55} fill="url(#orb)" />
          {/* Border glow */}
          <Circle cx={cx} cy={cy} r={r * 0.55} fill="none" stroke={config.color1} strokeWidth={1.5} strokeOpacity={0.6} />
          {/* Inner highlight */}
          <Circle cx={cx} cy={cy} r={r * 0.55} fill="url(#highlight)" />
          {/* Glass rim */}
          <Circle cx={cx} cy={cy} r={r * 0.56} fill="none" stroke="#FFFFFF" strokeWidth={0.5} strokeOpacity={0.15} />
        </Svg>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});
