export type GeminiCallbacks = {
  onConnected: () => void;
  onDisconnected: () => void;
  onReconnecting: () => void;
  onAudioReceived: (base64PCM: string) => void;
  onInputTranscript: (text: string) => void;
  onOutputTranscript: (text: string) => void;
  onTurnComplete: () => void;
  onError: (error: string) => void;
  onSetupComplete: () => void;
};

const SESSION_RENEW_MS = 540_000; // 9 minutes
const KEEPALIVE_INTERVAL_MS = 8_000;
const RECONNECT_DELAY_MS = 3_000;

class GeminiLiveClient {
  private ws: WebSocket | null = null;
  private apiKey: string;
  private model: string;
  private voice: string;
  private systemPrompt: string;
  private callbacks: GeminiCallbacks;
  private keepAliveTimer: ReturnType<typeof setInterval> | null = null;
  private sessionTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private shouldReconnect = true;
  private isDestroyed = false;

  constructor(
    apiKey: string,
    model: string,
    voice: string,
    systemPrompt: string,
    callbacks: GeminiCallbacks,
  ) {
    this.apiKey = apiKey;
    this.model = model;
    this.voice = voice;
    this.systemPrompt = systemPrompt;
    this.callbacks = callbacks;
  }

  connect() {
    if (this.isDestroyed) return;
    this.clearTimers();

    const url = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=${this.apiKey}`;

    try {
      this.ws = new WebSocket(url);
    } catch (e) {
      this.callbacks.onError('Failed to create WebSocket');
      this.scheduleReconnect();
      return;
    }

    this.ws.onopen = () => {
      if (this.isDestroyed) return;
      const setup = {
        setup: {
          model: this.model,
          system_instruction: { parts: [{ text: this.systemPrompt }] },
          generation_config: {
            response_modalities: ['AUDIO'],
            speech_config: {
              voice_config: {
                prebuilt_voice_config: { voice_name: this.voice },
              },
            },
            temperature: 0.9,
          },
          output_audio_transcription: {},
          input_audio_transcription: {},
        },
      };
      this.ws?.send(JSON.stringify(setup));
      this.callbacks.onConnected();

      // Keepalive
      this.keepAliveTimer = setInterval(() => {
        this.sendSilentPCM();
      }, KEEPALIVE_INTERVAL_MS);

      // Session renewal
      this.sessionTimer = setTimeout(() => {
        this.reconnect();
      }, SESSION_RENEW_MS);
    };

    this.ws.onmessage = (event) => {
      if (this.isDestroyed) return;
      try {
        const data = JSON.parse(event.data as string);

        if (data.setupComplete) {
          this.callbacks.onSetupComplete();
        }

        if (data.serverContent) {
          const sc = data.serverContent;

          if (Array.isArray(sc.modelTurn?.parts)) {
            for (const part of sc.modelTurn.parts) {
              if (part?.inlineData?.data) {
                this.callbacks.onAudioReceived(part.inlineData.data as string);
              }
            }
          }

          if (sc.outputTranscription?.text) {
            this.callbacks.onOutputTranscript(sc.outputTranscription.text as string);
          }

          if (sc.inputTranscription?.text) {
            this.callbacks.onInputTranscript(sc.inputTranscription.text as string);
          }

          if (sc.turnComplete) {
            this.callbacks.onTurnComplete();
          }
        }
      } catch {
        // Ignore parse errors silently
      }
    };

    this.ws.onclose = () => {
      if (this.isDestroyed) return;
      this.callbacks.onDisconnected();
      this.clearTimers();
      if (this.shouldReconnect) {
        this.scheduleReconnect();
      }
    };

    this.ws.onerror = () => {
      if (this.isDestroyed) return;
      this.callbacks.onError('WebSocket error');
    };
  }

  sendText(message: string) {
    if (this.ws?.readyState !== WebSocket.OPEN) return;
    const msg = {
      client_content: {
        turns: [{ role: 'user', parts: [{ text: message }] }],
        turn_complete: true,
      },
    };
    this.ws.send(JSON.stringify(msg));
  }

  sendAudio(base64PCM: string) {
    if (this.ws?.readyState !== WebSocket.OPEN) return;
    const msg = {
      realtime_input: {
        media_chunks: [{ mime_type: 'audio/pcm;rate=16000', data: base64PCM }],
      },
    };
    this.ws.send(JSON.stringify(msg));
  }

  interrupt() {
    if (this.ws?.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ client_content: { turns: [], turn_complete: true } }));
  }

  disconnect() {
    this.isDestroyed = true;
    this.shouldReconnect = false;
    this.clearTimers();
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.ws?.close();
    this.ws = null;
  }

  get isConnected() {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  private sendSilentPCM() {
    // 1024 bytes of silence (zeros) — ~32ms of PCM silence at 16kHz mono 16-bit
    const silence = new Uint8Array(1024);
    let binary = '';
    for (let i = 0; i < silence.length; i++) binary += String.fromCharCode(silence[i]);
    this.sendAudio(btoa(binary));
  }

  private reconnect() {
    this.clearTimers();
    this.ws?.close();
    this.ws = null;
    this.callbacks.onReconnecting();
    setTimeout(() => {
      if (!this.isDestroyed) this.connect();
    }, 100);
  }

  private scheduleReconnect() {
    this.reconnectTimer = setTimeout(() => {
      if (!this.isDestroyed) {
        this.callbacks.onReconnecting();
        this.connect();
      }
    }, RECONNECT_DELAY_MS);
  }

  private clearTimers() {
    if (this.keepAliveTimer) clearInterval(this.keepAliveTimer);
    if (this.sessionTimer) clearTimeout(this.sessionTimer);
    this.keepAliveTimer = null;
    this.sessionTimer = null;
  }
}

export default GeminiLiveClient;
