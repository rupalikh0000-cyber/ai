import { AppCommand } from '@/model/AppCommand';

export class CommandParser {
  static parse(text: string): AppCommand | null {
    const t = text.toLowerCase().trim();

    // Prime call
    if (/(close friend|mere close friend|my close friend).*(call|baat|phone)/i.test(t)) {
      return { type: 'PRIME_CALL', params: { index: '0' } };
    }
    if (/(second contact|second wala|2nd contact).*(call|baat)/i.test(t)) {
      return { type: 'PRIME_CALL', params: { index: '1' } };
    }

    // Prime msg
    if (/(close friend|meri jaan|my love|my close friend).*(msg|message|text)/i.test(t)) {
      return { type: 'PRIME_MSG', params: { index: '0' } };
    }

    // Open app
    const openMatch = t.match(/(?:open|kholo|launch|start)\s+(\w[\w\s]+)/i);
    if (openMatch) {
      return { type: 'OPEN_APP', params: { app_name: openMatch[1].trim() } };
    }

    // Close app
    const closeMatch = t.match(/(?:close|band karo|close karo)\s+(\w[\w\s]+)/i);
    if (closeMatch) {
      return { type: 'CLOSE_APP', params: { app_name: closeMatch[1].trim() } };
    }

    // Call person
    const callMatch = t.match(/(?:call|phone karo|call karo)\s+(.+)/i);
    if (callMatch && !t.includes('prime') && !t.includes('close friend')) {
      return { type: 'CALL', params: { name: callMatch[1].trim() } };
    }

    // SMS
    const smsMatch = t.match(/(?:sms|message|msg)\s+(.+?)\s+(?:ko|to)\s+(.+)/i);
    if (smsMatch) {
      return { type: 'SMS', params: { name: smsMatch[1], message: smsMatch[2] } };
    }

    // Volume
    if (/volume\s*(up|badhao|increase|upar|zyada)/i.test(t)) return { type: 'VOLUME_UP', params: {} };
    if (/volume\s*(down|kam|decrease|neeche|thoda|low)/i.test(t)) return { type: 'VOLUME_DOWN', params: {} };

    // Flashlight
    if (/(torch|flashlight)\s*(on|켜|on karo|chalu)/i.test(t)) return { type: 'FLASHLIGHT_ON', params: {} };
    if (/(torch|flashlight)\s*(off|band|bujhao)/i.test(t)) return { type: 'FLASHLIGHT_OFF', params: {} };

    // WiFi
    if (/wifi\s*(on|chalu|start)/i.test(t)) return { type: 'WIFI_ON', params: {} };
    if (/wifi\s*(off|band)/i.test(t)) return { type: 'WIFI_OFF', params: {} };

    // Bluetooth
    if (/bluetooth\s*(on|chalu|start)/i.test(t)) return { type: 'BLUETOOTH_ON', params: {} };
    if (/bluetooth\s*(off|band)/i.test(t)) return { type: 'BLUETOOTH_OFF', params: {} };

    return null;
  }
}
