import { Audio } from 'expo-av';
import * as FileSystem from 'expo-file-system';

class AudioEngine {
  private pcmChunks: Uint8Array[] = [];
  private currentSound: Audio.Sound | null = null;
  private recording: Audio.Recording | null = null;
  private _isSpeaking = false;
  private _isMuted = false;

  onAmplitudeChanged?: (amplitude: number) => void;
  onSpeakingStarted?: () => void;
  onSpeakingStopped?: () => void;

  async init() {
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: true,
      playsInSilentModeIOS: true,
      staysActiveInBackground: false,
    });
  }

  // Called for each PCM chunk received from Gemini (24kHz, mono, 16-bit)
  addAudioChunk(base64PCM: string) {
    const bytes = this.base64ToUint8Array(base64PCM);
    this.pcmChunks.push(bytes);
  }

  // Called when Gemini's turn is complete — flush all PCM chunks and play
  async flushAndPlay() {
    if (this.pcmChunks.length === 0) return;

    const totalLength = this.pcmChunks.reduce((sum, c) => sum + c.length, 0);
    const combined = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of this.pcmChunks) {
      combined.set(chunk, offset);
      offset += chunk.length;
    }
    this.pcmChunks = [];

    try {
      const wavData = this.createWAV(combined, 24000, 1, 16);
      const wavBase64 = this.uint8ArrayToBase64(wavData);
      const fileUri = `${FileSystem.cacheDirectory}resma_play_${Date.now()}.wav`;

      await FileSystem.writeAsStringAsync(fileUri, wavBase64, {
        encoding: FileSystem.EncodingType.Base64,
      });

      if (this.currentSound) {
        await this.currentSound.unloadAsync();
        this.currentSound = null;
      }

      this._isSpeaking = true;
      this.onSpeakingStarted?.();

      const { sound } = await Audio.Sound.createAsync({ uri: fileUri });
      this.currentSound = sound;

      sound.setOnPlaybackStatusUpdate((status) => {
        if (status.isLoaded && status.didJustFinish) {
          this._isSpeaking = false;
          this.onSpeakingStopped?.();
          sound.unloadAsync().catch(() => {});
          // Clean up temp file
          FileSystem.deleteAsync(fileUri, { idempotent: true }).catch(() => {});
        }
      });

      await sound.playAsync();
    } catch (e) {
      this._isSpeaking = false;
      this.onSpeakingStopped?.();
    }
  }

  stopPlayback() {
    this.currentSound?.stopAsync().catch(() => {});
    this.currentSound?.unloadAsync().catch(() => {});
    this.currentSound = null;
    this.pcmChunks = [];
    if (this._isSpeaking) {
      this._isSpeaking = false;
      this.onSpeakingStopped?.();
    }
  }

  async startRecording(): Promise<boolean> {
    if (this.recording) return false;
    try {
      const { status } = await Audio.requestPermissionsAsync();
      if (status !== 'granted') return false;

      const rec = new Audio.Recording();
      await rec.prepareToRecordAsync({
        ios: {
          extension: '.caf',
          outputFormat: Audio.IOSOutputFormat.LINEARPCM,
          audioQuality: Audio.IOSAudioQuality.HIGH,
          sampleRate: 16000,
          numberOfChannels: 1,
          bitRate: 256000,
          linearPCMBitDepth: 16,
          linearPCMIsBigEndian: false,
          linearPCMIsFloat: false,
        },
        android: {
          extension: '.3gp',
          outputFormat: Audio.AndroidOutputFormat.THREE_GPP,
          audioEncoder: Audio.AndroidAudioEncoder.AMR_NB,
          sampleRate: 16000,
          numberOfChannels: 1,
          bitRate: 128000,
        },
        web: {
          mimeType: 'audio/webm',
          bitsPerSecond: 128000,
        },
      } as Audio.RecordingOptions);

      rec.setOnRecordingStatusUpdate((s) => {
        if (s.metering !== undefined) {
          const normalized = Math.max(0, Math.min(1, (s.metering + 160) / 160));
          this.onAmplitudeChanged?.(normalized);
        }
      });

      await rec.startAsync();
      this.recording = rec;
      return true;
    } catch {
      return false;
    }
  }

  async stopRecording(): Promise<string | null> {
    if (!this.recording) return null;
    try {
      await this.recording.stopAndUnloadAsync();
      const uri = this.recording.getURI();
      this.recording = null;
      if (!uri) return null;
      const base64 = await FileSystem.readAsStringAsync(uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      return base64;
    } catch {
      this.recording = null;
      return null;
    }
  }

  setMuted(muted: boolean) {
    this._isMuted = muted;
  }

  get isMuted() { return this._isMuted; }
  get isSpeaking() { return this._isSpeaking; }

  async release() {
    await this.stopRecording();
    this.stopPlayback();
  }

  // --- Helpers ---

  private createWAV(pcm: Uint8Array, sampleRate: number, channels: number, bitsPerSample: number): Uint8Array {
    const dataLen = pcm.length;
    const buf = new ArrayBuffer(44 + dataLen);
    const v = new DataView(buf);
    const ws = (off: number, s: string) => {
      for (let i = 0; i < s.length; i++) v.setUint8(off + i, s.charCodeAt(i));
    };
    ws(0, 'RIFF');
    v.setUint32(4, 36 + dataLen, true);
    ws(8, 'WAVE');
    ws(12, 'fmt ');
    v.setUint32(16, 16, true);
    v.setUint16(20, 1, true);
    v.setUint16(22, channels, true);
    v.setUint32(24, sampleRate, true);
    v.setUint32(28, sampleRate * channels * (bitsPerSample / 8), true);
    v.setUint16(32, channels * (bitsPerSample / 8), true);
    v.setUint16(34, bitsPerSample, true);
    ws(36, 'data');
    v.setUint32(40, dataLen, true);
    const out = new Uint8Array(buf);
    out.set(pcm, 44);
    return out;
  }

  private base64ToUint8Array(b64: string): Uint8Array {
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  private uint8ArrayToBase64(bytes: Uint8Array): string {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  }
}

export default AudioEngine;
